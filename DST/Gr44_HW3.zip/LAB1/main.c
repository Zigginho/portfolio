#include "at91sam3x8.h"
#include "system_sam3x.h"
#include "core_cm3.h"
#include <stdio.h>
#include <math.h>
#define PIOB_DIFSR (AT91_CAST(AT91_REG *)  0x400E1084)
#define PIOB_AIMER (AT91_CAST(AT91_REG *)  0x400E10B0)
#define PIOB_SCDR  (AT91_CAST(AT91_REG *)  0x400E108C)

unsigned int InterruptCounter = 0;
int interrupt = 0;
int Temp = 0;
int p = 0;
int timeTemp = 0;
int time2 = 0;
int tempArray[] = {0,0};
int tempCount = 0;
int w = 0;
int readingTemperature = 0;
int flag;
int timeA = 0;
int timeB = 0;
void Delay(int value);
//----------------------------------------------------------------------------Board setup

void pinMode(unsigned int pin, char block, unsigned int output){
    
  // output Enables
  if (block == 'D' && output == 1){
    (*AT91C_PIOD_PER) = (1 << pin);
    (*AT91C_PIOD_OER) = (1 << pin); 
    (*AT91C_PIOD_PPUDR) = (1 << pin);
  }
  else if (block == 'C' && output == 1){
    (*AT91C_PIOC_PER) = (1 << pin);
    (*AT91C_PIOC_OER) = (1 << pin); 
    (*AT91C_PIOC_PPUDR) = (1 << pin);
  }
  else if (block == 'A' && output == 1){
    (*AT91C_PIOA_PER) = (1 << pin);
    (*AT91C_PIOA_OER) = (1 << pin); 
    (*AT91C_PIOA_PPUDR) = (1 << pin);
  }
  // output disables
  
    else if (block == 'D' && output == 0){
    (*AT91C_PIOD_PER) = (1 << pin);
    (*AT91C_PIOD_ODR) = (1 << pin); 
    (*AT91C_PIOD_PPUDR) = (1 << pin);
  }
  else if (block == 'C' && output == 0){
    (*AT91C_PIOC_PER) = (1 << pin);
    (*AT91C_PIOC_ODR) = (1 << pin); 
    (*AT91C_PIOC_PPUDR) = (1 << pin);
  }
  else if (block == 'A' && output == 0){
    (*AT91C_PIOA_PER) = (1 << pin);
    (*AT91C_PIOA_ODR) = (1 << pin);
    (*AT91C_PIOA_PPUDR) = (1 << pin);
  }
}

void configClock(){
  *AT91C_PMC_PCER = (1<<14);
  *AT91C_PMC_PCER = (1<<13);
  *AT91C_PMC_PCER = (1<<12);
}

//----------------------------------------------------------------------------sys tick interrupt

void SysTick_Handler(void){
  InterruptCounter++;
  if (InterruptCounter == 1000000){
    InterruptCounter = 0;
    interrupt = 1;
  }
}


//----------------------------------------------------------------------------Display setup

void Delay(int Value){
int i;
for(i=0;i<Value;i++)
asm("nop");
} 

unsigned char Read_Status_Display(void){

  unsigned char Temp;
  /*
  ODR och OER s�tta f�r att garantera clearade kanaler. l�st keypad 74 chip s� det inte kan p�verka resultatet.
  l�ser random siffror......
  */

  //make databus as input
  //(*AT91C_PIOC_CODR) = 0x3FC;
  (*AT91C_PIOC_ODR) = 0x3FC;
  //Set dir as input (74chip, 1 = input)
  (*AT91C_PIOC_OER) = (1 << 13);
  (*AT91C_PIOC_SODR) = (1 << 13);
  //(*AT91C_PIOC_ODR) = (1 << 13);
  //Clear/enable output (74chip 0 = enable)
  (*AT91C_PIOC_CODR) = (1 << 12);
  //(*AT91C_PIOC_ODR) = (1 << 12);
  //Set C/D
  (*AT91C_PIOC_OER) = (1 << 14);
  (*AT91C_PIOC_SODR) = (1 << 14);
  //Clear chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //(*AT91C_PIOC_ODR) = (1 << 15);
  //Clear read display
  (*AT91C_PIOC_CODR) = (1 << 16);
  //(*AT91C_PIOC_ODR) = (1 << 16);
  //Make a Delay
  Delay(22);
  //Read data bus and save it in temp           //kan r�cka med att bara l�sa 0&1 om jag f�rst�r dokumentationen. //sid 13 p� raio dokumentation. 
  Temp = (*AT91C_PIOC_PDSR) &0xC;
  //Set chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //(*AT91C_PIOC_ODR) = (1 << 15);
  //Set read display
  (*AT91C_PIOC_OER) = (1 << 16);
  (*AT91C_PIOC_SODR) = (1 << 16);
  //Disable output (74chip)
  (*AT91C_PIOC_OER) = (1 << 12);
  (*AT91C_PIOC_SODR) = (1 << 12);
  //Set dir as output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 13);
  //(*AT91C_PIOC_ODR) = (1 << 13);
  return (Temp); 
}

void Write_Command_2_Display(unsigned char Command){
  while (Read_Status_Display() != 0xC) {
  }
  //Clear databus
  (*AT91C_PIOC_CODR) = 0x3FC;      
  //(*AT91C_PIOC_ODR) = 0x3FC;
  //Set Command to databus
  (*AT91C_PIOC_OER) = (1 << 2); //2
  (*AT91C_PIOC_SODR) = (Command << 2);
  //Set dir as output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 13);
  //Enable output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 12);
  //(*AT91C_PIOC_ODR) = (1 << 12);
  //Set databus as output
  (*AT91C_PIOC_OER) = 0x3FC;
  //Set C/D signal High (1 = Command)
  (*AT91C_PIOC_OER) = (1 << 14);
  (*AT91C_PIOC_SODR) = (1 << 14);
  //Clear chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //Clear write display
  (*AT91C_PIOC_CODR) = (1 << 17);
  //Make a Delay
  Delay(22);
  //Set chip enable display
  (*AT91C_PIOC_OER) = (1 << 17);
  (*AT91C_PIOC_SODR) = (1 << 17);
  //Set write display
  (*AT91C_PIOC_OER) = (1 << 15);
  (*AT91C_PIOC_SODR) = (1 << 15);
  //Disable output (74chip)
  (*AT91C_PIOC_OER) = (1 << 12);
  (*AT91C_PIOC_SODR) = (1 << 12);
  //Make databus as input
  (*AT91C_PIOC_ODR) = 0x3FC;

}

void Write_Data_2_Display(unsigned char Data){
//Wait until Read_Status_Display returns an OK
while (Read_Status_Display() != 0xC) { //0xC
  }
 //Clear databus
  (*AT91C_PIOC_CODR) = 0x3FC;  
  //set data to databus
  (*AT91C_PIOC_SODR)=(Data<<2);
//Set dir as output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 13);
//Enable output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 12);
  //(*AT91C_PIOC_ODR) = (1 << 12);
//Set databus as output
  (*AT91C_PIOC_OER) = 0x3FC;
//Clear C/D signal High (0 = Data)
  (*AT91C_PIOC_CODR) = (1 << 14);
  //(*AT91C_PIOC_ODR) = (1 << 14);
 //Clear chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //(*AT91C_PIOC_ODR) = (1 << 15);
//Clear write display
  (*AT91C_PIOC_CODR) = (1 << 17);
  //(*AT91C_PIOC_ODR) = (1 << 17);
//Make a Delay
Delay(10);
  //Set chip enable display
  (*AT91C_PIOC_OER) = (1 << 17);
  (*AT91C_PIOC_SODR) = (1 << 17);
//Set write display
  (*AT91C_PIOC_OER) = (1 << 15);
  (*AT91C_PIOC_SODR) = (1 << 15);
//Disable output (74chip)
  (*AT91C_PIOC_OER) = (1 << 12);
  (*AT91C_PIOC_SODR) = (1 << 12);
//make databus as input
  (*AT91C_PIOC_ODR) = 0x3FC;
}

void Init_Display(void){
  
  pinMode(13, 'C', 1);  //Display Dir
  pinMode(12, 'C', 1);  //OE bus Display
  pinMode(14, 'C', 1);  //C/D
  pinMode(15, 'C', 1);  //Chip Select Display
  pinMode(16, 'C', 1);  //Read display 
  pinMode(17, 'C', 1);  //Chip enable display
  pinMode(0, 'D', 1);  //Display reset
  
  //Clear Reset display
  (*AT91C_PIOD_CODR) = (1 << 0);
  //Make a Delay
  Delay(10);
  //Set Reset display
  (*AT91C_PIOD_SODR) = (1 << 0);
  Write_Data_2_Display(0x00);
  Write_Data_2_Display(0x00);
  Write_Command_2_Display(0x40);//Set text home address
  Write_Data_2_Display(0x00);
  Write_Data_2_Display(0x40);
  Write_Command_2_Display(0x42); //Set graphic home addresss
  Write_Data_2_Display(0x1e);
  Write_Data_2_Display(0x00);
  Write_Command_2_Display(0x41); // Set text area
  Write_Data_2_Display(0x1e);
  Write_Data_2_Display(0x00);
  Write_Command_2_Display(0x43); // Set graphic area
  Write_Command_2_Display(0x80); // text mode
  Write_Command_2_Display(0x94); // Text on graphic off
         
} 

void ClearDisp(void){
  //clear
  Write_Data_2_Display(0x00);
  Write_Data_2_Display(0x00);
  
  Write_Command_2_Display(0x24);      //set the adress pointer 
 
  for(int i = 0; i < 16*30; i++){     //clear the screen
    Write_Data_2_Display(0x00);         
    Write_Command_2_Display(0xC0);
  }
}

//-------------------------------------------------------------------------Print to display
void dWrite(int number){
  int x = 0;
  int array[5] = {0,0,0,0,0};
    while(number > 0)
    {
      x++;
      array[x] = number % 10;
      number = number / 10;
    }
  for(x; x >0; x-- ){
    Write_Data_2_Display(array[x] + 16); 
    Write_Command_2_Display(0xC0);
  }
}

void ReadLight(void){
  //Setup pins  
  
  unsigned int Light = 0/*pin out*/;
    
  unsigned char value = 0x10;           
  value = value + (unsigned char) Light; //look at the displayboard on blackboard on the diagram(reminder:
  Write_Data_2_Display(0x0); 
  Write_Data_2_Display(0x0);
  Write_Command_2_Display(0x24); 
  Write_Data_2_Display(value);
  Write_Command_2_Display(0xC0); 

}

void TC0_Handler()
{
  *AT91C_TC0_IDR = (1 << 6);
  timeA = *AT91C_TC0_RA; 
  timeB = *AT91C_TC0_RB;
  
  flag = 1;                
  readingTemperature = 0;          

}

void tempSensorInitialiser()
{
   *AT91C_PMC_PCER = (1 << 12) ;
   *AT91C_PIOB_PER = (1 << 25);
   *AT91C_PMC_PCER = (1 << 27); 
   *AT91C_TC0_CMR = (*AT91C_TC0_CMR & 0xFFFE ); 
   *AT91C_TC0_CCR = (5 << 0); 
   *AT91C_TC0_CMR = (*AT91C_TC0_CMR |(2 << 16)); 
   *AT91C_TC0_CMR = (*AT91C_TC0_CMR |(1 << 18)); 
   
   NVIC_EnableIRQ ((IRQn_Type)27);  
   NVIC_ClearPendingIRQ((IRQn_Type)27);  
}
void tempRead(){
    readingTemperature = 1;
    *AT91C_TC0_IER = (1 << 6); 
    *AT91C_PIOB_OER = (1 << 25);  
    
    Delay(25);
    
    *AT91C_PIOB_ODR = (1 << 25); 
    *AT91C_TC0_CCR = (1 << 2); 
}   
int readTemp(){
  int temp = (((timeB-timeA)/(210))-273.15);
  dWrite(temp);
  
  return temp;
}
//light-----------------------------------------------------------------------------------------
void ljusInitialise(){
  *AT91C_PMC_PCER1 = (1 << 5);
  *AT91C_ADCC_MR = (1 << 9);  //14Mhz
}

int measureLjus(){
   *AT91C_ADCC_IER = (1 << 2);
   *AT91C_ADCC_CHER = (1 << 2);
   *AT91C_ADCC_CR = (1 << 1);
   
   while(*AT91C_ADCC_SR & (1 << 24) == (1 << 24)){
   }
   int ljus = *AT91C_ADCC_LCDR & 0XFFF;
   //dWrite(((4095-ljus)/1240.9));
   dWrite((ljus));
   
   return ljus;
}
//servon----------------------------------------------------------------------------------------------------------------------

void turnServo(int angle){
   *AT91C_PWMC_CH1_CDTYR = angle*23.35 + 1832.5;
}

void servoInitiate(){
  *AT91C_PMC_PCER = (1 << 12); 
  *AT91C_PIOB_PPUDR = (1 << 17); 
  *AT91C_PIOB_PDR = (1 << 17);
  *AT91C_PWMC_ENA = (1 << 1);
  *AT91C_PMC_PCER1 = (1 << 4); 
  *AT91C_PIOB_ABMR = (1 << 17);
  *AT91C_PWMC_CH1_CMR = 0x5;
  *AT91C_PWMC_CH1_CPRDR = 0xCD14;
  
  turnServo(0);
}

int checkKeypad(void){

  pinMode(2, 'C', 0);  //Rad 4
  pinMode(4, 'C', 0);  //Rad 2
  pinMode(5, 'C', 0);  //Rad 1
  pinMode(3, 'C', 0);  //Rad 3
  pinMode(7, 'C', 1);  //Kolumn 3
  pinMode(8, 'C', 1);  //Kolumn 2
  pinMode(9, 'C', 1);  //Kolumn 1

  (*AT91C_PIOD_CODR) = (1 << 2);        //clear OE BUS
  (*AT91C_PIOC_OER) = (1 << 7);
  (*AT91C_PIOC_OER) = (1 << 9);
  (*AT91C_PIOC_OER) = (1 << 8);
  (*AT91C_PIOC_ODR) = (1 << 2);
  (*AT91C_PIOC_ODR) = (1 << 3);
  (*AT91C_PIOC_ODR) = (1 << 4);
  (*AT91C_PIOC_ODR) = (1 << 5);

  int value = 0;

  unsigned int i,j;
  (*AT91C_PIOC_SODR) = (1 << 7);
  (*AT91C_PIOC_SODR) = (1 << 8);
  (*AT91C_PIOC_SODR) = (1 << 9);

  for(i = 7; i < 10; i++){
    (*AT91C_PIOC_CODR) = (1 << i);
    for(j = 2; j < 6; j++){
      if (((~*AT91C_PIOC_PDSR) &(1 << j)) == (1 << j)){

        //converion
        int row = j-2;
        int kolumn = i-7;
        value = (row*3)+(kolumn+1);
      }
    }
    (*AT91C_PIOC_SODR) = (1 << i);
  }
  (*AT91C_PIOD_SODR) = (1 << 2);        //set OE BUS
  return(value);
}
//--------------------------------------------------------------------------Main loop
unsigned int button=0;
void main(void){
  SystemInit();
  configClock();
  SysTick_Config(84);
  pinMode(3, 'D', 1);  //led
  pinMode(2, 'D', 1);  //Override?
  pinMode(2, 'C', 0);  //Rad 4
  pinMode(4, 'C', 0);  //Rad 2
  pinMode(5, 'C', 0);  //Rad 1
  pinMode(3, 'C', 0);  //Rad 3
  pinMode(7, 'C', 0);  //Kolumn 3
  pinMode(8, 'C', 0);  //Kolumn 2  
  pinMode(9, 'C', 0);  //Kolumn 1
  pinMode(13, 'C', 1);  //Display Dir
  pinMode(12, 'C', 1);  //OE bus Display
  pinMode(14, 'C', 1);  //C/D
  pinMode(15, 'C', 1);  //Chip Select Display
  pinMode(16, 'C', 1);  //Read display 
  pinMode(17, 'C', 1);  //Chip enable display
  pinMode(0, 'D', 1);  //Display reset
  Init_Display();
  ClearDisp();
  ljusInitialise();
  tempSensorInitialiser();
  servoInitiate();
  Delay(2500000);
  while(1){
    if(interrupt == 1){
      interrupt=0;
      Write_Data_2_Display(0x0); 
      Write_Data_2_Display(0x0);
      Write_Command_2_Display(0x24);
      tempRead();
      //measureLjus();
    }
    if(flag == 1){
      flag = 0;
      readTemp();
    }
    button = checkKeypad();
    if(button == 1){
      turnServo(10);
    }
    if(button == 2){
      turnServo(20);
    }
    if(button == 3){
    turnServo(30);
    }
    if(button == 4){
      turnServo(40);
    }
    if(button == 5){
      turnServo(50);
    }
    if(button == 6){
      turnServo(60);
    }
    if(button == 7){
      turnServo(70);
    }
    if(button == 8){
      turnServo(80);
    }
    if(button == 9){
      turnServo(90);
    }
}
}