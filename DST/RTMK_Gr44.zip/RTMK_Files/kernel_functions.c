#include <string.h>  /* for using the function memcpy        */

#include "kernel_functions.h"
int Ticks; /* global sysTick counter */
int KernelMode; /* can be equal to either INIT or RUNNING (constants defined
 * in ?kernel_functions.h?)*/

void insert(list* inputList, listobj* inputObj);
void idleTask(){while(1);} //simply to stop kernel from running dry

TCB *PreviousTask, *NextTask; /* Pointers to previous and next running tasks */
list *ReadyList, *WaitingList, *TimerList;

//------------------------------------------------------------------Auxilliary functions-------------------------------------------------------------

  //----------------------------------------------Double Linked List------------------------------------------------------------------------


list *createList(){
  /*creates a "list", cleans up the data and allocates space */
  
  list *newPointer = (list *)calloc(1,sizeof(list));
  if (newPointer == NULL)       //if adress == null return Fail
  {
    return FAIL;
  }
  newPointer->pHead = NULL;     //set the head pointer to NULL guaranteeing an empty spot for future functions
  if(newPointer->pHead != NULL)
  {
    return FAIL;
  }
  newPointer->pTail = NULL;     //set the tail pointer to NULL guaranteeing an empty spot for future functions
  if(newPointer->pTail !=NULL)
  {
    return FAIL;
  }
  return newPointer; //returning the pointer to the list.
}

listobj* pop(listobj* inputObj, list* inputList){
  
  if(inputObj != inputList->pHead && inputObj != inputList->pTail){     //if the given object is not head or tail of the input list->
    inputObj->pPrevious->pNext = inputObj->pNext;       //close the pointers around the given object
    inputObj->pNext->pPrevious = inputObj->pPrevious;
  }
  
  if(inputObj == inputList->pHead){     //if the given object is the head of the input list
    inputObj->pNext->pPrevious = NULL;  
    inputList->pHead = inputObj->pNext; 
   
  }
    if(inputObj == inputList->pTail){     ////if the given object is the head of the input list
    inputObj->pPrevious->pNext = NULL;
    inputList->pTail = inputObj->pPrevious;
  }
  return inputObj;
}

void insert(list* inputList, listobj* inputObj){
  //inserts the object into the list and sorts it based on deadline
  if(inputList->pHead == NULL && inputList->pTail == NULL)  //is the list empty
  {
    inputList->pTail = inputObj;    //set the given object as head and tail of the list
    inputList->pHead = inputObj;
  }

  else
  {
    
    if(inputList->pHead == inputList->pTail)      //if there is only 1 object in the list
    {     
      if(inputObj->pTask->Deadline < inputList->pTail->pTask->Deadline) //if object deadline is smaller then move object to the front of the line.
      {
        inputList->pTail->pPrevious = inputObj;
        inputObj->pNext = inputList->pTail;
        inputObj->pPrevious = NULL;
        inputList->pTail->pNext = NULL;
        inputList->pHead = inputObj;
      }
     
      else if(inputObj->pTask->Deadline > inputList->pTail->pTask->Deadline){   //if object deadline is smaller then move object to the back of the line.
        inputList->pHead->pNext= inputObj;
        inputObj->pPrevious = inputList->pHead;
        inputObj->pNext = NULL;
        inputList->pHead->pPrevious = NULL;
        inputList->pTail = inputObj;
      }
    }
    else {
      listobj * current;
      current = inputList->pHead;
        //in cases with more objects in the list.
      while(current != NULL){
        if(inputObj->pTask->Deadline < current->pTask->Deadline){
          //for cases involving the head node
          if(current == inputList->pHead){
            inputObj->pNext = current;
            current->pPrevious = inputObj; 
            inputObj->pPrevious = NULL;
            inputList->pHead = inputObj;
            break;
          }
          //for cases involving the tail node
          if(current == inputList->pTail){
            inputObj->pPrevious = current->pPrevious;
            inputObj->pNext = current;
            current->pPrevious->pNext = inputObj;
            current->pPrevious = inputObj;
            break;
          }
          // all other cases
          if(current != inputList->pTail && current != inputList->pHead){
            inputObj->pNext = current;
            inputObj->pPrevious = current->pPrevious;
            current->pPrevious->pNext = inputObj;
            current->pPrevious = inputObj;
            break;
          }
        }
        
        current = current->pNext;
        if(current == NULL){ // If it didnt find a spot for the object set it as the new tail.
          inputList->pTail->pNext = inputObj;
          inputObj->pPrevious = inputList->pTail;
          inputList->pTail->pNext->pNext = NULL;
          inputList->pTail = inputObj;
          break;
        }
      }
    }
  }
}

  //--------------------------------------------Mailbox Functions-------------------------------------------------------------------------
 

msg *new_msg_Obj(){
  /*Creates a "list object", cleans up the data and allocates memory */
  msg *newPointer = (msg *)calloc(1,sizeof(msg)); //allocate data
  if (newPointer == NULL)     //check that the message object was created
  {
    return NULL;
  }
  
  else
  {
    return newPointer;
  }
  
}


msg *popMsg(msg *inputMsg){
  /* removes the message from the list and connects the pointers around it*/
    inputMsg->pPrevious->pNext = inputMsg->pNext;
    inputMsg->pNext->pPrevious = inputMsg->pPrevious;
    inputMsg->pNext = NULL;
    inputMsg->pPrevious = NULL;
    
    return inputMsg;
}


//removing the mailbox needed for debugging
exception remove_mailbox(mailbox *mBox){
    if (mBox->pHead == NULL && mBox->pTail == NULL)
    {
        free(mBox->pHead);
        free(mBox->pTail);
        free(mBox);
        return OK;
    }

    else
    {
        return NOT_EMPTY;
    }
}

void insertMsg(mailbox **mBox,msg **temp){
  //insets the message into the end of the mailbox.
  (*mBox)->pTail->pPrevious->pNext = (*temp);
  (*temp)->pNext = (*mBox)->pTail;
  (*temp)->pPrevious = (*mBox)->pTail->pPrevious;
  (*mBox)->pTail->pPrevious = (*temp);
}

//-------------------------------------------------------------------Task administration--------------------------------------------------------------

exception init_kernel(){
  //initiates the kernel
  Ticks = 0; 
  TimerList = createList();
  ReadyList = createList();
  WaitingList = createList();
  create_task(&idleTask, 0xFFFFFFF); //idle task to prevent crashing if the kernel runns dry
  KernelMode = INIT;
  return OK;
}

void terminate(){
  isr_off();
  listobj *leavingObject = pop(ReadyList->pHead,ReadyList);
  NextTask = ReadyList->pHead->pTask;
  switch_to_stack_of_next_task();
  free(leavingObject->pTask);
  free(leavingObject);
  LoadContext_In_Terminate();
}

void run(){
  Ticks = 0;
  KernelMode = RUNNING;
  NextTask = ReadyList->pHead->pTask;
  LoadContext_In_Run();
}

exception create_task (void (*taskBody)(), unsigned int deadline){
  
  TCB *new_tcb;
  new_tcb = (TCB *)calloc(1,sizeof(TCB));
  if(new_tcb == NULL)       //cheking that the allocation was successfull..
  {
    return FAIL;        //fail if listobj is not empty
  }
  new_tcb->PC = taskBody;
  new_tcb->SPSR = 0x21000000;
  new_tcb->Deadline = deadline;
  new_tcb->StackSeg [STACK_SIZE - 2] = 0x21000000;
  new_tcb->StackSeg [STACK_SIZE - 3] = (unsigned int) taskBody;
  new_tcb->SP = &(new_tcb->StackSeg [STACK_SIZE - 9]);
  
  listobj * temp = (listobj *) calloc(1,sizeof(listobj));
  temp->pTask = new_tcb;
  temp->nTCnt = 0;
  temp->pMessage = NULL;
  temp->pPrevious = NULL;
  temp->pNext = NULL;
  if (KernelMode == INIT)
  {
    insert(ReadyList,temp);       //insert the new task into the ready list.
    return OK;
  }
  else  //if a task is already running
  {
    isr_off();
    PreviousTask = NextTask;
    insert(ReadyList,temp);  
    NextTask = ReadyList->pHead->pTask;
    SwitchContext();
  }
  return OK;
}





//---------------------------------------------------------------------Communication----------------------------------------------------------------------

mailbox *create_mailbox(int nof_msg, int size_of_msg){
  mailbox *tempMbox = (mailbox *)calloc(1,sizeof(mailbox));       //allocate space for the mailbox
  tempMbox->pHead = (msg *)calloc(1,sizeof(msg));
  tempMbox->pTail = (msg *)calloc(1,sizeof(msg));
  if (tempMbox == NULL)
  {
    return FAIL;    //check if allocation was sucessfull
  }   
  if (tempMbox->pHead == NULL)    
  {
    free(tempMbox);
    return FAIL;
  }
  if (tempMbox->pTail == NULL)
  {
    free(tempMbox->pHead);
    free(tempMbox);
    return FAIL;
  }
  
  tempMbox->pHead->pNext = tempMbox->pTail;   //sets the data for the new mailbox
  tempMbox->pTail->pPrevious = tempMbox->pHead;
  tempMbox->pHead->pPrevious = NULL;
  tempMbox->pTail->pNext = NULL;
  
  tempMbox->nDataSize = size_of_msg;      
  tempMbox->nMaxMessages = nof_msg;
  tempMbox->nMessages =0;
  
  return tempMbox;
}

exception send_wait(mailbox *mBox, void* Data){
 isr_off();
 msg* newPointer = mBox->pHead->pNext;
 if(mBox->nMessages > 0 && newPointer->Status == RECEIVER){
   memcpy(newPointer->pData,Data,mBox->nDataSize);

   //function to make the list work
   popMsg(newPointer);
   free(newPointer->pData);
   free(newPointer);
   mBox->nMessages -= 1;
   
   //update task order
   PreviousTask = NextTask;
   
   // remove receiving task from list
   listobj* move = pop(newPointer->pBlock,WaitingList);
   mBox->nBlockedMsg -= 1;
   
   //Insert receiving task in ReadyList
   insert(ReadyList,move);
   
   //Update NextTask
   NextTask = ReadyList->pHead->pTask;
 } 
  else
  {
    //Allocate a Message structure
    msg * newPointer2 = new_msg_Obj();
    newPointer2->pData = (void*)malloc(sizeof(mBox->nDataSize));
    newPointer2->Status = SENDER;
    newPointer2->pMail = mBox;
    
    //Set data pointer
    newPointer2->pData = Data;
    newPointer2->pBlock = ReadyList->pHead;
    
    //Add the Message to the Mailbox
    insertMsg(&mBox,&newPointer2);
    mBox->nMessages++;
    
    //Update PreviousTask
    PreviousTask = NextTask;
    
    //Move sending task to waiting list
    listobj* move = pop(ReadyList->pHead,ReadyList);
    insert(WaitingList,move);
    mBox->nBlockedMsg++;

    //Update NextTask with the new ready list
    NextTask = ReadyList->pHead->pTask;
  }
 SwitchContext();
 if(NextTask->Deadline <= Ticks){       //if the deadline is reached
   isr_off();
   msg *newTmp = mBox->pHead->pNext;
   popMsg(newPointer);
   free(newTmp->pData);
   free(newTmp);
   mBox->nMessages-= 1;
   isr_on();
        
        return DEADLINE_REACHED;
    }
    else
    {
        return OK;
    }
}

exception receive_wait(mailbox* mBox, void* Data){
    isr_off();
    msg *newPointer = mBox->pHead->pNext;
    if (mBox->nMessages > 0 && newPointer->Status == SENDER)
    {
        //Copy senders data to receiving tasks data area
        memcpy(Data,newPointer->pData, mBox->nDataSize);

        //Remove sending tasks Message struct from the Mailbox 
        popMsg(newPointer);
        mBox->nMessages--;

        //if Message was of wait type
        if (newPointer->pBlock != NULL)
        {
            //Update PreviousTask
            PreviousTask = NextTask;

            //Move sending task to ReadyList
           listobj * newPointer2 = pop(newPointer->pBlock,WaitingList);
           insert(ReadyList,newPointer2);
            mBox->nBlockedMsg--;

            //Update NextTask
            NextTask = ReadyList->pHead->pTask;
        }

        else
        {
            //Free senders data area
            free(newPointer->pData);
        }
    }

    else
    {
        //Allocate a Message structure
        msg *newPointer3 = new_msg_Obj();
        newPointer3->Status = RECEIVER;
        newPointer3->pMail = mBox;

        //Add Message to the Mailbox
        insertMsg(&mBox,&newPointer3);
        mBox->nMessages++;

        //Update PreviousTask
        PreviousTask = NextTask;

        //Move receiving task from ReadyList to WaitingList
        listobj* newPointer4  = pop(ReadyList->pHead,ReadyList);
        insert(WaitingList,newPointer4);
        mBox->nBlockedMsg++;

        //Update NextTask
        NextTask = ReadyList->pHead->pTask;
    }

    SwitchContext();

    //if deadline is reached
    if (NextTask->Deadline <= Ticks)
    {
        isr_off();
        
        //Remove receive Message
        msg *newTmp = mBox->pHead;
        popMsg(newTmp);
        free(newTmp);
        mBox->nMessages-=1;
        mBox->nBlockedMsg-=1;
        isr_on();
        
        return DEADLINE_REACHED;
    }
    else
    {
        return OK;
    }
}

exception send_no_wait(mailbox *mBox, void *Data){
    isr_off();
    msg *newPointer = mBox->pHead->pNext;
    
    if (mBox->nMessages > 0 && newPointer->Status == RECEIVER)
    {
        //copy data to receiver
        memcpy(newPointer->pData, Data, mBox->nDataSize);
        
        //Remove receiving tasks Message struct from the mailbox
        popMsg(newPointer);
        mBox->nMessages-=1;

        //Update PreviousTask
        PreviousTask = NextTask;
        
        //Insert receiving task in ReadyList
        listobj* move = pop(newPointer->pBlock,WaitingList);
        
        insert(ReadyList,move);
        mBox->nBlockedMsg-=1;

        //Update NextTask
        NextTask = ReadyList->pHead->pTask;

        SwitchContext();
    }

    else
    {
        //Allocate a Message structure
        msg *newPointer3 = new_msg_Obj();
        newPointer3->pData = (void*)malloc(sizeof(mBox->nDataSize));
        newPointer3->Status = SENDER;
       
        //Copy Data to the Message
        memcpy(newPointer3->pData, Data, mBox->nDataSize);
      
        if (mBox->nMessages == mBox->nMaxMessages)
        {
            msg *removeMsg = mBox->pHead->pNext;
            popMsg(removeMsg);
            free(removeMsg->pData);
            free(removeMsg);
            mBox->nMessages--;
        }      
        insertMsg(&mBox,&newPointer3);
        mBox->nMessages++;
        
    }
     return OK;
}

exception receive_no_wait(mailbox *mBox, void *Data){
    isr_off();
     msg* newPointer = mBox->pHead->pNext;
    if (mBox->nMessages > 0 && newPointer->Status > 0)
    {
        memcpy(Data,newPointer->pData, mBox->nDataSize);

        //Remove sending tasks Message struct from the Mailbox
       popMsg(newPointer);
       free(newPointer);

        mBox->nMessages--;

        //if Message was of wait type
        if (newPointer->pBlock != NULL)
        {
            //Update PreviousTask
            PreviousTask = NextTask;

            //Move sending task to ReadyList
            listobj * newPointer3 = pop(newPointer->pBlock,WaitingList);
            insert(ReadyList,newPointer3);
            mBox->nBlockedMsg--;
            
            //Update NextTask
            NextTask = ReadyList->pHead->pTask;
            SwitchContext();
        }

        else
        {
            //Free senders data area
            free(newPointer->pData);
            free(newPointer);

        }
    }

    else
    {
        return FAIL;
    }
    return OK;
}


//-------------------------------------------------------------------Timing-----------------------------------------------------------------------------------

exception wait(uint nTicks){
    isr_off();
    PreviousTask = NextTask;

    listobj *newPointer = pop(ReadyList->pHead,ReadyList);
    newPointer->nTCnt = nTicks;

    insert(TimerList,newPointer);
    NextTask = ReadyList->pHead->pTask;

    SwitchContext();

    if (NextTask->Deadline < Ticks)
    {
        return DEADLINE_REACHED;
    }
    else
    {
        return OK;
    }
}

void set_ticks(uint nTicks){
    Ticks = nTicks;
}

uint ticks(void){
    return Ticks;
}

uint deadline(void){
    return NextTask->Deadline;
}

void set_deadline(uint deadline){
    /*Disable interrupt*/
    isr_off();

    /*Set the deadline field in the calling TCB.*/
    NextTask->Deadline = deadline;

    /*Update PreviousTask*/
    PreviousTask = NextTask;

    /*Reschedule Readylist*/
    listobj *newPointer = pop(ReadyList->pHead,ReadyList);
    insert(ReadyList,newPointer);

    /*Update NextTask*/
    NextTask = ReadyList->pHead->pTask;

    /*Switch context*/
    SwitchContext();
}

void TimerInt(void){
    Ticks++;
    listobj *temp = TimerList->pHead;

    while (temp != NULL)
    {
      temp->nTCnt--;
        if (temp->nTCnt == 0 || temp->pTask->Deadline < Ticks)
        {         PreviousTask = NextTask;
                  listobj * move = pop(temp,TimerList);
                  insert(ReadyList,move);
                  NextTask = ReadyList->pHead->pTask;
                  temp = temp->pNext;
        }
        
        else{
        temp = temp->pNext;
        }
    }
    
    listobj *temp2 = WaitingList->pHead;
    
    while (temp2 != NULL)
    {
        if (temp2->pTask->Deadline < Ticks)
        {
            listobj * move = pop(temp2,WaitingList);
            insert(ReadyList,move);
            msg* remove = popMsg(move->pMessage);
            move->pMessage = NULL;
            temp2 = temp2->pNext;
            remove->pMail->nMessages--;
            remove->pMail->nBlockedMsg--;
            free(remove->pData);
            free(remove);
            PreviousTask = NextTask;
            NextTask = ReadyList->pHead->pTask;
        }
        
        else{
        temp2 = temp2->pNext;
        }  
    }
}













