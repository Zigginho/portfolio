#include "at91sam3x8.h"
#include "system_sam3x.h"
#include "core_cm3.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
#define PIOB_DIFSR (AT91_CAST(AT91_REG *)  0x400E1084)
#define PIOB_AIMER (AT91_CAST(AT91_REG *)  0x400E10B0)
#define PIOB_SCDR  (AT91_CAST(AT91_REG *)  0x400E108C)

int InterruptCounter = 0;
int interrupt = 0;
int flag = 0;
int flag2 = 0;
int timeA = 0;
int timeB = 0;
int seconds = 0;
int minutes = 0;
int hours = 0;
int day = 0;
int month = 0;
int year = 0;
char y[50] = {0};
int dayValues[1440];
float averagearray[7];
int minarray[7];
int maxarray[7];
int minhourarray[7];
int minminarray[7];
int maxhourarray[7];
int maxminarray[7];
float variancearray[7];
char timestamp[50];
int memorycounter = 0;
int minutecounter = 0;
int daycounter = 0;
int mode = 60;
int sad = 0;
int max = 0;
int min = 100000;
int temperature;
unsigned int button=78;
unsigned int menuflag = 1;
int ljus;
int tempGot = 1;

//----------------------------------------------------------------------------Board setup

void pinMode(unsigned int pin, char block, unsigned int output){
    
  // output Enables
  if (block == 'D' && output == 1){
    (*AT91C_PIOD_PER) = (1 << pin);
    (*AT91C_PIOD_OER) = (1 << pin); 
    (*AT91C_PIOD_PPUDR) = (1 << pin);
  }
  else if (block == 'C' && output == 1){
    (*AT91C_PIOC_PER) = (1 << pin);
    (*AT91C_PIOC_OER) = (1 << pin); 
    (*AT91C_PIOC_PPUDR) = (1 << pin);
  }
  else if (block == 'A' && output == 1){
    (*AT91C_PIOA_PER) = (1 << pin);
    (*AT91C_PIOA_OER) = (1 << pin); 
    (*AT91C_PIOA_PPUDR) = (1 << pin);
  }
  // output disables
  
    else if (block == 'D' && output == 0){
    (*AT91C_PIOD_PER) = (1 << pin);
    (*AT91C_PIOD_ODR) = (1 << pin); 
    (*AT91C_PIOD_PPUDR) = (1 << pin);
  }
  else if (block == 'C' && output == 0){
    (*AT91C_PIOC_PER) = (1 << pin);
    (*AT91C_PIOC_ODR) = (1 << pin); 
    (*AT91C_PIOC_PPUDR) = (1 << pin);
  }
  else if (block == 'A' && output == 0){
    (*AT91C_PIOA_PER) = (1 << pin);
    (*AT91C_PIOA_ODR) = (1 << pin);
    (*AT91C_PIOA_PPUDR) = (1 << pin);
  }
}

void configClock(){
  *AT91C_PMC_PCER = (1<<14);
  *AT91C_PMC_PCER = (1<<13);
  *AT91C_PMC_PCER = (1<<12);
}

//----------------------------------------------------------------------------sys tick interrupt

void SysTick_Handler(void){
  InterruptCounter++;
  if (InterruptCounter==999) {
    InterruptCounter = 0;
    interrupt = 1;
    seconds += mode;
  }
}

//----------------------------------------------------------------------------Display setup

void Delay(int Value){
int i;
for(i=0;i<Value;i++)
asm("nop");
} 

unsigned char Read_Status_Display(void){

  unsigned char Temp;
  /*
  ODR och OER s�tta f�r att garantera clearade kanaler. l�st keypad 74 chip s� det inte kan p�verka resultatet.
  l�ser random siffror......
  */

  //make databus as input
  //(*AT91C_PIOC_CODR) = 0x3FC;
  (*AT91C_PIOC_ODR) = 0x3FC;
  //Set dir as input (74chip, 1 = input)
  (*AT91C_PIOC_OER) = (1 << 13);
  (*AT91C_PIOC_SODR) = (1 << 13);
  //(*AT91C_PIOC_ODR) = (1 << 13);
  //Clear/enable output (74chip 0 = enable)
  (*AT91C_PIOC_CODR) = (1 << 12);
  //(*AT91C_PIOC_ODR) = (1 << 12);
  //Set C/D
  (*AT91C_PIOC_OER) = (1 << 14);
  (*AT91C_PIOC_SODR) = (1 << 14);
  //Clear chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //(*AT91C_PIOC_ODR) = (1 << 15);
  //Clear read display
  (*AT91C_PIOC_CODR) = (1 << 16);
  //(*AT91C_PIOC_ODR) = (1 << 16);
  //Make a Delay
  Delay(22);
  //Read data bus and save it in temp           //kan r�cka med att bara l�sa 0&1 om jag f�rst�r dokumentationen. //sid 13 p� raio dokumentation. 
  Temp = (*AT91C_PIOC_PDSR) &0xC;
  //Set chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //(*AT91C_PIOC_ODR) = (1 << 15);
  //Set read display
  (*AT91C_PIOC_OER) = (1 << 16);
  (*AT91C_PIOC_SODR) = (1 << 16);
  //Disable output (74chip)
  (*AT91C_PIOC_OER) = (1 << 12);
  (*AT91C_PIOC_SODR) = (1 << 12);
  //Set dir as output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 13);
  //(*AT91C_PIOC_ODR) = (1 << 13);
  return (Temp); 
}

void Write_Command_2_Display(unsigned char Command){
  while (Read_Status_Display() != 0xC) {
  }
  //Clear databus
  (*AT91C_PIOC_CODR) = 0x3FC;      
  //(*AT91C_PIOC_ODR) = 0x3FC;
  //Set Command to databus
  (*AT91C_PIOC_OER) = (1 << 2); //2
  (*AT91C_PIOC_SODR) = (Command << 2);
  //Set dir as output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 13);
  //Enable output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 12);
  //(*AT91C_PIOC_ODR) = (1 << 12);
  //Set databus as output
  (*AT91C_PIOC_OER) = 0x3FC;
  //Set C/D signal High (1 = Command)
  (*AT91C_PIOC_OER) = (1 << 14);
  (*AT91C_PIOC_SODR) = (1 << 14);
  //Clear chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //Clear write display
  (*AT91C_PIOC_CODR) = (1 << 17);
  //Make a Delay
  Delay(22);
  //Set chip enable display
  (*AT91C_PIOC_OER) = (1 << 17);
  (*AT91C_PIOC_SODR) = (1 << 17);
  //Set write display
  (*AT91C_PIOC_OER) = (1 << 15);
  (*AT91C_PIOC_SODR) = (1 << 15);
  //Disable output (74chip)
  (*AT91C_PIOC_OER) = (1 << 12);
  (*AT91C_PIOC_SODR) = (1 << 12);
  //Make databus as input
  (*AT91C_PIOC_ODR) = 0x3FC;

}

void Write_Data_2_Display(unsigned char Data){
//Wait until Read_Status_Display returns an OK
while (Read_Status_Display() != 0xC) { //0xC
  }
 //Clear databus
  (*AT91C_PIOC_CODR) = 0x3FC;  
  //set data to databus
  (*AT91C_PIOC_SODR)=(Data<<2);
//Set dir as output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 13);
//Enable output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 12);
  //(*AT91C_PIOC_ODR) = (1 << 12);
//Set databus as output
  (*AT91C_PIOC_OER) = 0x3FC;
//Clear C/D signal High (0 = Data)
  (*AT91C_PIOC_CODR) = (1 << 14);
  //(*AT91C_PIOC_ODR) = (1 << 14);
 //Clear chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //(*AT91C_PIOC_ODR) = (1 << 15);
//Clear write display
  (*AT91C_PIOC_CODR) = (1 << 17);
  //(*AT91C_PIOC_ODR) = (1 << 17);
//Make a Delay
Delay(10);
  //Set chip enable display
  (*AT91C_PIOC_OER) = (1 << 17);
  (*AT91C_PIOC_SODR) = (1 << 17);
//Set write display
  (*AT91C_PIOC_OER) = (1 << 15);
  (*AT91C_PIOC_SODR) = (1 << 15);
//Disable output (74chip)
  (*AT91C_PIOC_OER) = (1 << 12);
  (*AT91C_PIOC_SODR) = (1 << 12);
//make databus as input
  (*AT91C_PIOC_ODR) = 0x3FC;
}

void Init_Display(void){
  
  pinMode(13, 'C', 1);  //Display Dir
  pinMode(12, 'C', 1);  //OE bus Display
  pinMode(14, 'C', 1);  //C/D
  pinMode(15, 'C', 1);  //Chip Select Display
  pinMode(16, 'C', 1);  //Read display 
  pinMode(17, 'C', 1);  //Chip enable display
  pinMode(0, 'D', 1);  //Display reset
  
  //Clear Reset display
  (*AT91C_PIOD_CODR) = (1 << 0);
  //Make a Delay
  Delay(10);
  //Set Reset display
  (*AT91C_PIOD_SODR) = (1 << 0);
  Write_Data_2_Display(0x00);
  Write_Data_2_Display(0x00);
  Write_Command_2_Display(0x40);//Set text home address
  Write_Data_2_Display(0x00);
  Write_Data_2_Display(0x40);
  Write_Command_2_Display(0x42); //Set graphic home addresss
  Write_Data_2_Display(0x1e);
  Write_Data_2_Display(0x00);
  Write_Command_2_Display(0x41); // Set text area
  Write_Data_2_Display(0x1e);
  Write_Data_2_Display(0x00);
  Write_Command_2_Display(0x43); // Set graphic area
  Write_Command_2_Display(0x80); // text mode
  Write_Command_2_Display(0x94); // Text on graphic off
  Write_Command_2_Display(0xA0); //1 line cursor
         
} 

void setAdress(char x, char y){
  
  Write_Data_2_Display(x); 
  Write_Data_2_Display(y);
  Write_Command_2_Display(0x24);        //set adress pointer
}

void ClearDisp(void){
  //clear
  setAdress(0x0, 0x0);      //set the adress pointer 
  for(int i = 0; i < 16*40; i++){     //clear the screen
    Write_Data_2_Display(0x00);         
    Write_Command_2_Display(0xC0);
  }
}

//-------------------------------------------------------------------------Print to display

char* float2char(float x){
    
    char temp[10];
    sprintf(temp, "%.3f", x);
    int i = 0;
    while (temp[i] != '\0'){
      y[i] = temp[i];
      i++;
    }
    y[i] = '\0';
    return y;
}

char* int2char(int x){
  /*
converts integers to printeable char.
*/
  int j = 0;
  int k = 0;
  int l = 0;
  if (x == 0){
    y[0] = 0 + '0';
    y[1] = '\0';
    return y;
  }
  while (x > 0){
    k = k*10;
    k = k+(x % 10);
    
    if (k == 0){
    l = 1;
    }
    x = x / 10;
  }
  x = k;
  while (x > 0){
    int m = x % 10;
    y[j] = m+'0'; //allt m�ste in i rad 2 p� font chart. s� allt m�ste ha 0 i slutet.
    j++;
    x = x / 10;
  }
  if (l == 1){
    l = 0;
    y[j] = 0 + '0';
    y[j+1] = '\0';
    return y;
  }
  y[j] = '\0';
  return y;
}

void dWrite(char message[]){
  /*

*/
  int x = 0;
  while (message[x] != '\0') x++;
    
  for(int i = 0; i < x; i++ ){
    Write_Data_2_Display(message[i] - 32);
    Write_Command_2_Display(0xC0);
  }
}

//------------------------------------------------------------------------Temp


void TC0_Handler(){
  *AT91C_TC0_IDR = (1 << 6);
  //timeA = *AT91C_TC0_RA;        //load timeA on LDRA
  //timeB = *AT91C_TC0_RB;        //load timeB on LDRA
  flag = 1;                        

}

void tempSensorInitialiser(){
   *AT91C_PMC_PCER = (1 << 12); // Peripheral Clock Enable Register 
   *AT91C_PMC_PCER = (1 << 27); // Peripheral Clock Enable Register
   *AT91C_TC0_CMR = (*AT91C_TC0_CMR & 0xFFFE );         //(TCLK1)     
   *AT91C_TC0_CCR = (5 << 0);   //enable and SW reset on CCR
   *AT91C_TC0_CMR = (*AT91C_TC0_CMR |(2 << 16));        //setup LDRA to capture on Falling edge   
   *AT91C_TC0_CMR = (*AT91C_TC0_CMR |(1 << 18));        //setup LDRB to capture on rising edge
   *AT91C_PIOB_PER = (1 << 25); // PIO Enable Register
   *AT91C_PIOB_OER = (1 << 25);
   *AT91C_PIOB_SODR= (1 << 25); //init  
   //Delay(25);
   //*AT91C_PIOB_CODR= (1 << 25); //init 
   
   
   NVIC_SetPriority(TC0_IRQn, 1);  //Set priority
   NVIC_ClearPendingIRQ(TC0_IRQn);  //Clear pending                clear before enabling.
   NVIC_EnableIRQ (TC0_IRQn);  //enable NVIC 
}
   
void tempRead(){
  if(tempGot == 1){
    tempGot = 0;
    //*AT91C_TC0_IER = (0x1<<6);           //Enable interrupt LDRBS
    *AT91C_PIOB_OER = AT91C_PIO_PB25;      //Enable output on pin 25.
    *AT91C_PIOB_CODR = AT91C_PIO_PB25;        //Creating a startpuls
    
    Delay(25);                       //25 ticks delay dosnt work with 25ms
    
    *AT91C_PIOB_SODR = AT91C_PIO_PB25;        //Stops the puls page 10 sam3xA
    *AT91C_PIOB_ODR = AT91C_PIO_PB25;        //Disable output on pin 25.
    *AT91C_TC0_CCR = (1 <<  2);           //SW reset on CCR //0x1 <<  2
    //volatile int dummy = *AT91C_TC0_SR;
    //((*AT91C_TC0_SR) &(1 << 6)) == (1 << 0); //check status register..............
    volatile int dummy = (*AT91C_TC0_SR &(1 << 6)); //read Status register
    //Delay(25); //10*84
    *AT91C_TC0_IER = (1<<6);           //Enable interrupt LDRBS
    
    Delay(200000);
  }
}   

int tempGet(){
  timeA = *AT91C_TC0_RA;        //load timeA on LDRA
  timeB = *AT91C_TC0_RB;
  int temp = (timeB-timeA)/210-273.15;
  tempGot = 1;
  return temp;
}



//light-----------------------------------------------------------------------------------------

void ljusInitialise(){
  *AT91C_PMC_PCER1 = (1 << 5);
  *AT91C_ADCC_MR = (1 << 9);  //14Mhz
}

int Ljusread(){
   *AT91C_ADCC_CHER = (1 << 2);
   *AT91C_ADCC_CR = (1 << 1);
   
   while(*AT91C_ADCC_SR & (1 << 24) == (1 << 24));
   int ljus = *AT91C_ADCC_LCDR & 0XFFF;
   //dWrite(((4095-ljus)/1240.9));
   return ljus;
}

//servon----------------------------------------------------------------------------------------------------------------------

void turnServo(int angle){
   *AT91C_PWMC_CH1_CDTYR = angle*28 + 1000;        //setting the duty cycle between 0 and 180 degrees bottom should be 315
}

void servoInitiate(){
  *AT91C_PMC_PCER = (1 << 12); 
  *AT91C_PIOB_PPUDR = (1 << 17); 
  *AT91C_PIOB_PDR = (1 << 17);
  *AT91C_PWMC_ENA = (1 << 1);
  *AT91C_PMC_PCER1 = (1 << 4); 
  *AT91C_PIOB_ABMR = (1 << 17);
  *AT91C_PWMC_CH1_CMR = 0x5;    //sets the Channel Mode Register prescale 32 left aligned
  *AT91C_PWMC_CH1_CPRDR = 0xCD14;         //setting channel period register to 52�500 == 20ms    
  
  turnServo(0);
}

int checkKeypad(void){

  pinMode(2, 'C', 0);  //Rad 4
  pinMode(4, 'C', 0);  //Rad 2
  pinMode(5, 'C', 0);  //Rad 1
  pinMode(3, 'C', 0);  //Rad 3
  pinMode(7, 'C', 1);  //Kolumn 3
  pinMode(8, 'C', 1);  //Kolumn 2
  pinMode(9, 'C', 1);  //Kolumn 1

  (*AT91C_PIOD_CODR) = (1 << 2);        //clear OE BUS
  (*AT91C_PIOC_OER) = (1 << 7);
  (*AT91C_PIOC_OER) = (1 << 9);
  (*AT91C_PIOC_OER) = (1 << 8);
  (*AT91C_PIOC_ODR) = (1 << 2);
  (*AT91C_PIOC_ODR) = (1 << 3);
  (*AT91C_PIOC_ODR) = (1 << 4);
  (*AT91C_PIOC_ODR) = (1 << 5);

  int value = 78;

  unsigned int i,j;
  (*AT91C_PIOC_SODR) = (1 << 7);
  (*AT91C_PIOC_SODR) = (1 << 8);
  (*AT91C_PIOC_SODR) = (1 << 9);

  for(i = 7; i < 10; i++){
    (*AT91C_PIOC_CODR) = (1 << i);
    for(j = 2; j < 6; j++){
      if (((~*AT91C_PIOC_PDSR) &(1 << j)) == (1 << j)){

        //converion
        int row = j-2;
        int kolumn = i-7;
        value = (row*3)+(kolumn+1);
      }
    }
    (*AT91C_PIOC_SODR) = (1 << i);
  }
  (*AT91C_PIOD_SODR) = (1 << 2);        //set OE BUS
  if (value == 11){
  value = 0;
  }
  return(value);
}

//Clock/Calendar-----------------------------------------------------------------------------------------

void average(int array[1440]){
  float total = 0;
  for(int i = 0; i < 1440 ; i++){
    total = total + array[i];
  }
  total = total/1440;
  
  averagearray[daycounter] = total;
}

void variance (int array[1440]){
  
  float varianceAnswer = 0;
  for(int i = 0; i < 1440 ; i++){
    varianceAnswer += pow((array[i]-averagearray[daycounter]), 2);
  }
  varianceAnswer = varianceAnswer/1440;
  variancearray[daycounter] = varianceAnswer;
}

void maxFunction (int array[1440]){
  int maxValue = array[1439];
  int j = 0;
  for(int i = 1439; i >= 0; i--){
    if(array[i] > maxValue){
      maxValue = array[i];
      j = i+1;
    }
  }

  maxhourarray[daycounter] = j / 60;
  maxminarray[daycounter] = j % 60;
  maxarray[daycounter] = maxValue;
}

void minFunction (int array[1440]){
  int minValue = array[1439];
  int j = 0;
  for(int i = 1439; i >= 0; i--){
    if(array[i] < minValue){
      minValue = array[i];
      j = i+1;
    }
  }
  
  minhourarray[daycounter] = j / 60;
  minminarray[daycounter] = j % 60;
  minarray[daycounter] = minValue;
}

void second(int on){

  if (seconds >= 60){
    flag2 = 1;
    seconds = 0;
    minutes++;
    }
  if (minutes >= 60){
      minutes = 0;
      hours++;
    }
  if (hours >= 24){
        day++;
        menuflag = 1;
        hours = 0;
    }
  if (day >= 31){
    month++;
    day = 1;
    }
  if (month >= 13){
    year++;
    month = 1;
    }
  
  if (on == 1){
  setAdress(0xF, 0x0);  //x, y
  //clock
  dWrite("        ");
  setAdress(0xF, 0x0);  //x, y
  dWrite(int2char(hours));
  Write_Data_2_Display(0x1A);
  Write_Command_2_Display(0xC0);
  dWrite(int2char(minutes));
  Write_Data_2_Display(0x1A);
  Write_Command_2_Display(0xC0);
  dWrite(int2char(seconds));
  }
}

char* createTimestamp(int year, int month, int day, int clock, int hours, int minutes){
    
    char tempstamp[50] = {'\0'};
    strcat(tempstamp, " ");
    strcat(tempstamp, int2char(day));
    strcat(tempstamp, "/");
    strcat(tempstamp, int2char(month));
    strcat(tempstamp, "/");
    strcat(tempstamp, int2char(year));
    
    if (clock == 1){
      strcat(tempstamp, " ");
      strcat(tempstamp, int2char(hours));
      strcat(tempstamp, ":");
      strcat(tempstamp, int2char(minutes));
    }
    int i;
    for (i = 0; tempstamp[i] != '\0'; i++){
      timestamp[i] = tempstamp[i];
    }
    timestamp[i] = ' ';
    timestamp[i+1] = '\0';
    
    return timestamp;
}

void saveValues(int temp){
  dayValues[minutecounter] = temp;
  memorycounter++;
  minutecounter++;
  if (minutecounter == 1440){
    minutecounter = 0;
    average(dayValues);
    minFunction(dayValues);
    maxFunction(dayValues);
    variance(dayValues);
    daycounter++;
    }
   
    
    
    if (memorycounter == 10080){
      memorycounter = 0;
      daycounter = 0;
    }    
}

void printNew(int temp){
  createTimestamp(year, month, day, 1, hours, minutes);
  
    if (temp > max){
      max = temp;
      setAdress(0x46, 0x0);
      dWrite("MAX");
      dWrite(timestamp);
      dWrite(" ");
      dWrite(int2char(temp));
    }
    
    if (temp < min){
      min = temp;
      setAdress(0x28, 0x0);
      dWrite("MIN");
      dWrite(timestamp);
      dWrite(" ");
      dWrite(int2char(temp));
   }
}

void updater(void){

  if (flag2 == 1){
      flag2 = 0;
      saveValues(temperature);
    } 
    
    if(interrupt == 1){
      second(0);
      tempRead(); 
      interrupt = 0;
      button = checkKeypad();
      ljus = Ljusread() - 200;
      turnServo((ljus*0.18));
      }
      
     if(flag == 1){
      flag = 0;
      temperature = tempGet(); //<-----------------
     }
}

void updateCalendar(void){
int loop = 0;
  button = 78;
  start:
  ClearDisp();
      setAdress(0x0, 0x1);
      dWrite("Type in date clear with *");
      loop = 1;
      setAdress(0xA, 0x0);
      //year
      unsigned int tempdate = 0;
      for (int m = 0; m < 4; m++){
        loop = 1;
        while (loop == 1){
          button = checkKeypad();
          updater();
          if (button != 78){
            dWrite(int2char(button));
            tempdate = tempdate * 10;
            tempdate += button;
            loop = 0;
            Delay(4000000);
          }
        }
        if (button == 10){
        break;
        }
      }
      year = tempdate;
      if (button == 10){
        goto start;
      }
      Write_Data_2_Display(0x1A);
      Write_Command_2_Display(0xC0);
      //month
      tempdate = 0;
      for (int m = 0; m < 2; m++){
        loop = 1;
        while (loop == 1){
          button = checkKeypad();
          updater();
          if (button != 78){
            dWrite(int2char(button));
            tempdate = tempdate * 10;
            tempdate += button;
            loop = 0;
            Delay(4000000);
          }
        }
        if (button == 10){
        break;
        }
      }
      month = tempdate;
      if (button == 10){
        goto start;
      }
      Write_Data_2_Display(0x1A);
      Write_Command_2_Display(0xC0);
      //day
      tempdate = 0;
      for (int m = 0; m < 2; m++){
        loop = 1;
        while (loop == 1){
          button = checkKeypad();
          updater();
          if (button != 78){
            dWrite(int2char(button));
            tempdate = tempdate * 10;
            tempdate += button;
            loop = 0;
            Delay(4000000);
          }
        }
        if (button == 10){
        break;
        }
      }
      day = tempdate;
      if (button == 10){
        goto start;
      }
      ClearDisp();
 }

//menu-----------------------------------------------------------------------------

void menuAverage(void){

ClearDisp();
button = 78;
setAdress(0x28, 0x0);
for (int i = 0; i < daycounter; i++){
  
  if (day < daycounter){
    dWrite(createTimestamp(year, month-1, 30-(daycounter-day), 0, 0, 0));
    dWrite(float2char(averagearray[i]));
  }
  else{
    dWrite(createTimestamp(year, month, day-(daycounter-i), 0, 0, 0));
    dWrite(float2char(averagearray[i]));
  }
  }
while (button != 10){
updater();
}
}

void menuVariance(void){
  
ClearDisp();
button = 78;
setAdress(0x28, 0x0);

for (int i = 0; i < daycounter; i++){
  
  if (day < daycounter){
    dWrite(createTimestamp(year, month-1, 30-(daycounter-day), 0, 0, 0));
    dWrite(float2char(variancearray[i]));
  }
  else{
    dWrite(createTimestamp(year, month, day-(daycounter-i), 0, 0, 0));
    dWrite(float2char(variancearray[i]));
  }
  }
while (button != 10){
updater();
}
}

void menuMin(void){
  
ClearDisp();
button = 78;
setAdress(0x28, 0x0);

for (int i = 0; i < daycounter; i++){
    if (day < daycounter){
    dWrite(createTimestamp(year, month-1, 30-(daycounter-day), 1, minhourarray[i], minminarray[i]));
    dWrite(int2char(minarray[i]));
  }
  else{
    dWrite(createTimestamp(year, month, day-(daycounter-i), 0, 0, 0));
    dWrite(int2char(minarray[i]));
  }
  }
while (button != 10){
 updater();
}
}

void menuMax(void){
  
ClearDisp();
button = 78;
setAdress(0x28, 0x0);

for (int i = 0; i < daycounter; i++){
   if (day < daycounter){
    dWrite(createTimestamp(year, month-1, 30-(daycounter-day), 1, maxhourarray[i], maxminarray[i]));
    dWrite(int2char(maxarray[i]));
  }
  else{
    dWrite(createTimestamp(year, month, day-(daycounter - i), 1, maxhourarray[i], maxminarray[i]));
    dWrite(int2char(maxarray[i]));
  }
  }
while (button != 10){
  updater();
  }
}

void menu(void){
  
  button = 78;
  menuflag = 1;
printmenu:
  ClearDisp();
  setAdress(0x28, 0x0);
  dWrite("press 4 variance"); 
  
  setAdress(0x46, 0x0);
  dWrite("press 5 average"); 
  
  setAdress(0x64, 0x0);
  dWrite("press 6 MAX"); 
  
  setAdress(0x82, 0x0);
  dWrite("press 7 MIN"); 
  
  setAdress(0xA0, 0x0);
  dWrite("press 8 to date :)"); 
  
  setAdress(0xBE, 0x0);
  dWrite("press * to return;"); 
  
  Delay(8400000);
  
  int loop = 1;
  
  while(loop == 1){
    
    updater();
    
    if (button == 10){
      ClearDisp();
      return;
    }
    if (button == 8){
      updateCalendar();
      goto printmenu;
      }
    if (button == 5){
      menuAverage();
      goto printmenu;
      }
     if (button == 6){
      menuMax();
      goto printmenu;
      }
     if (button == 7){
      menuMin();
      goto printmenu;
      }
     if (button == 4){
      menuVariance();
      goto printmenu;
      }
    }
}

//--------------------------------------------------------------------------Main loop


void main(void){
  int pipflag = 0;
  SystemInit();
  configClock();
  SysTick_Config(84000);
  
  pinMode(3, 'D', 1);  //led
  pinMode(2, 'D', 1);  //Override?
  pinMode(2, 'C', 0);  //Rad 4
  pinMode(4, 'C', 0);  //Rad 2
  pinMode(5, 'C', 0);  //Rad 1
  pinMode(3, 'C', 0);  //Rad 3
  pinMode(7, 'C', 0);  //Kolumn 3
  pinMode(8, 'C', 0);  //Kolumn 2  
  pinMode(9, 'C', 0);  //Kolumn 1
  pinMode(13, 'C', 1);  //Display Dir
  pinMode(12, 'C', 1);  //OE bus Display
  pinMode(14, 'C', 1);  //C/D
  pinMode(15, 'C', 1);  //Chip Select Display
  pinMode(16, 'C', 1);  //Read display 
  pinMode(17, 'C', 1);  //Chip enable display
  pinMode(0, 'D', 1);  //Display reset
  
  Init_Display();
  ClearDisp();
  ljusInitialise();
  tempSensorInitialiser();
  servoInitiate();
  Delay(2500000);
  setAdress(0x0, 0x0);  //x, y
  
  tempRead(); 
  temperature = tempGet();
    
    while(1){
    
 
    if (button == 5){
      menu();
    }
    
     if (flag2 == 1){
      flag2 = 0;
      saveValues(temperature);
      printNew(temperature);
    } 
    
    if(interrupt == 1){
      second(1);
      interrupt = 0;
      button = checkKeypad();
      tempRead();
      ljus = Ljusread() - 300;
      turnServo((ljus*0.18));
      }
      
     if(flag == 1){
      flag = 0;
      temperature = tempGet(); //<-----------------
      setAdress(0x0, 0x0);  //x, y
      dWrite(int2char(temperature));
      
      if ((temperature > 25) || (temperature < 20)){
        pipflag = 1;
        setAdress(0x1, 0x1);
        dWrite("*piip*");
      }
      else if (pipflag == 1){
        pipflag = 0;
        setAdress(0x1, 0x1);
        dWrite("      ");
      }
    }
      
      if (menuflag == 1){
          menuflag = 0;
          setAdress(0x82, 0x0);
          dWrite("Press 5 for menu");
          //calendar
          dWrite("        ");
          setAdress(0x96, 0x1);  //x, y
          dWrite(int2char(day));
          dWrite("/");
          dWrite(int2char(month));
          dWrite("/");
          dWrite(int2char(year));
      }
  }
}