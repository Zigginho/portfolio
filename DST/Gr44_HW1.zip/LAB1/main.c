#include "at91sam3x8.h"
#include "system_sam3x.h"
#include "core_cm3.h"
#include <stdio.h>

unsigned int InterruptCounter = 0;
int interrupt = 0;

//----------------------------------------------------------------------------Board setup

void pinMode(unsigned int pin, char block, unsigned int output){
    
  // output Enables
  if (block == 'D' && output == 1){
    (*AT91C_PIOD_PER) = (1 << pin);
    (*AT91C_PIOD_OER) = (1 << pin); 
    (*AT91C_PIOD_PPUDR) = (1 << pin);
  }
  else if (block == 'C' && output == 1){
    (*AT91C_PIOC_PER) = (1 << pin);
    (*AT91C_PIOC_OER) = (1 << pin); 
    (*AT91C_PIOC_PPUDR) = (1 << pin);
  }
  else if (block == 'A' && output == 1){
    (*AT91C_PIOA_PER) = (1 << pin);
    (*AT91C_PIOA_OER) = (1 << pin); 
    (*AT91C_PIOA_PPUDR) = (1 << pin);
  }
  // output disables
  
    else if (block == 'D' && output == 0){
    (*AT91C_PIOD_PER) = (1 << pin);
    (*AT91C_PIOD_ODR) = (1 << pin); 
    (*AT91C_PIOD_PPUDR) = (1 << pin);
  }
  else if (block == 'C' && output == 0){
    (*AT91C_PIOC_PER) = (1 << pin);
    (*AT91C_PIOC_ODR) = (1 << pin); 
    (*AT91C_PIOC_PPUDR) = (1 << pin);
  }
  else if (block == 'A' && output == 0){
    (*AT91C_PIOA_PER) = (1 << pin);
    (*AT91C_PIOA_ODR) = (1 << pin);
    (*AT91C_PIOA_PPUDR) = (1 << pin);
  }
}

void configClock(){
  *AT91C_PMC_PCER = (1<<14);
  *AT91C_PMC_PCER = (1<<13);
}

//----------------------------------------------------------------------------sys tick interrupt

void SysTick_Handler(void){
  InterruptCounter++;
  if (InterruptCounter == 1000){
    InterruptCounter = 0;
    interrupt = 1;
  }
}


//----------------------------------------------------------------------------Display setup

void Delay(int Value){
int i;
for(i=0;i<Value;i++)
asm("nop");
} 

unsigned char Read_Status_Display(void){

  unsigned char Temp;
  /*
  ODR och OER s�tta f�r att garantera clearade kanaler. l�st keypad 74 chip s� det inte kan p�verka resultatet.
  l�ser random siffror......
  */

  //make databus as input
  //(*AT91C_PIOC_CODR) = 0x3FC;
  (*AT91C_PIOC_ODR) = 0x3FC;
  //Set dir as input (74chip, 1 = input)
  (*AT91C_PIOC_OER) = (1 << 13);
  (*AT91C_PIOC_SODR) = (1 << 13);
  //(*AT91C_PIOC_ODR) = (1 << 13);
  //Clear/enable output (74chip 0 = enable)
  (*AT91C_PIOC_CODR) = (1 << 12);
  //(*AT91C_PIOC_ODR) = (1 << 12);
  //Set C/D
  (*AT91C_PIOC_OER) = (1 << 14);
  (*AT91C_PIOC_SODR) = (1 << 14);
  //Clear chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //(*AT91C_PIOC_ODR) = (1 << 15);
  //Clear read display
  (*AT91C_PIOC_CODR) = (1 << 16);
  //(*AT91C_PIOC_ODR) = (1 << 16);
  //Make a Delay
  Delay(22);
  //Read data bus and save it in temp           //kan r�cka med att bara l�sa 0&1 om jag f�rst�r dokumentationen. //sid 13 p� raio dokumentation. 
  Temp = (*AT91C_PIOC_PDSR) &0xC;
  //Set chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //(*AT91C_PIOC_ODR) = (1 << 15);
  //Set read display
  (*AT91C_PIOC_OER) = (1 << 16);
  (*AT91C_PIOC_SODR) = (1 << 16);
  //Disable output (74chip)
  (*AT91C_PIOC_OER) = (1 << 12);
  (*AT91C_PIOC_SODR) = (1 << 12);
  //Set dir as output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 13);
  //(*AT91C_PIOC_ODR) = (1 << 13);
  return (Temp); 
}

void Write_Command_2_Display(unsigned char Command){
  while (Read_Status_Display() != 0xC) {
  }
  //Clear databus
  (*AT91C_PIOC_CODR) = 0x3FC;      
  //(*AT91C_PIOC_ODR) = 0x3FC;
  //Set Command to databus
  (*AT91C_PIOC_OER) = (1 << 2); //2
  (*AT91C_PIOC_SODR) = (Command << 2);
  //Set dir as output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 13);
  //Enable output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 12);
  //(*AT91C_PIOC_ODR) = (1 << 12);
  //Set databus as output
  (*AT91C_PIOC_OER) = 0x3FC;
  //Set C/D signal High (1 = Command)
  (*AT91C_PIOC_OER) = (1 << 14);
  (*AT91C_PIOC_SODR) = (1 << 14);
  //Clear chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //Clear write display
  (*AT91C_PIOC_CODR) = (1 << 17);
  //Make a Delay
  Delay(22);
  //Set chip enable display
  (*AT91C_PIOC_OER) = (1 << 17);
  (*AT91C_PIOC_SODR) = (1 << 17);
  //Set write display
  (*AT91C_PIOC_OER) = (1 << 15);
  (*AT91C_PIOC_SODR) = (1 << 15);
  //Disable output (74chip)
  (*AT91C_PIOC_OER) = (1 << 12);
  (*AT91C_PIOC_SODR) = (1 << 12);
  //Make databus as input
  (*AT91C_PIOC_ODR) = 0x3FC;

}

void Write_Data_2_Display(unsigned char Data){
//Wait until Read_Status_Display returns an OK
while (Read_Status_Display() != 0xC) { //0xC
  }
 //Clear databus
  (*AT91C_PIOC_CODR) = 0x3FC;  
  //set data to databus
  (*AT91C_PIOC_SODR)=(Data<<2);
//Set dir as output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 13);
//Enable output (74chip)
  (*AT91C_PIOC_CODR) = (1 << 12);
  //(*AT91C_PIOC_ODR) = (1 << 12);
//Set databus as output
  (*AT91C_PIOC_OER) = 0x3FC;
//Clear C/D signal High (0 = Data)
  (*AT91C_PIOC_CODR) = (1 << 14);
  //(*AT91C_PIOC_ODR) = (1 << 14);
 //Clear chip select display
  (*AT91C_PIOC_CODR) = (1 << 15);
  //(*AT91C_PIOC_ODR) = (1 << 15);
//Clear write display
  (*AT91C_PIOC_CODR) = (1 << 17);
  //(*AT91C_PIOC_ODR) = (1 << 17);
//Make a Delay
Delay(10);
  //Set chip enable display
  (*AT91C_PIOC_OER) = (1 << 17);
  (*AT91C_PIOC_SODR) = (1 << 17);
//Set write display
  (*AT91C_PIOC_OER) = (1 << 15);
  (*AT91C_PIOC_SODR) = (1 << 15);
//Disable output (74chip)
  (*AT91C_PIOC_OER) = (1 << 12);
  (*AT91C_PIOC_SODR) = (1 << 12);
//make databus as input
  (*AT91C_PIOC_ODR) = 0x3FC;
}

void Init_Display(void){
  
  pinMode(13, 'C', 1);  //Display Dir
  pinMode(12, 'C', 1);  //OE bus Display
  pinMode(14, 'C', 1);  //C/D
  pinMode(15, 'C', 1);  //Chip Select Display
  pinMode(16, 'C', 1);  //Read display 
  pinMode(17, 'C', 1);  //Chip enable display
  pinMode(0, 'D', 1);  //Display reset
  
  //Clear Reset display
  (*AT91C_PIOD_CODR) = (1 << 0);
  //Make a Delay
  Delay(10);
  //Set Reset display
  (*AT91C_PIOD_SODR) = (1 << 0);
  Write_Data_2_Display(0x00);
  Write_Data_2_Display(0x00);
  Write_Command_2_Display(0x40);//Set text home address
  Write_Data_2_Display(0x00);
  Write_Data_2_Display(0x40);
  Write_Command_2_Display(0x42); //Set graphic home addresss
  Write_Data_2_Display(0x1e);
  Write_Data_2_Display(0x00);
  Write_Command_2_Display(0x41); // Set text area
  Write_Data_2_Display(0x1e);
  Write_Data_2_Display(0x00);
  Write_Command_2_Display(0x43); // Set graphic area
  Write_Command_2_Display(0x80); // text mode
  Write_Command_2_Display(0x94); // Text on graphic off
         
} 

void ClearDisp(void){
  //clear
  Write_Data_2_Display(0x00);
  Write_Data_2_Display(0x00);
  
  Write_Command_2_Display(0x24);      //set the adress pointer 
 
  for(int i = 0; i < 16*30; i++){     //clear the screen
    Write_Data_2_Display(0x00);         
    Write_Command_2_Display(0xC0);
  }
}

//-------------------------------------------------------------------------Print to display

void ReadTemp(void){
  //Setup pins  
  
  
  unsigned int Temp = /*pin out*/;
    
  unsigned char value = 0x10; //s�tter �vre bit till 0001 sedan korresponderar de l�gre bitsen 1 tillt 1 med siffrorna vi f�r i temp eller light. sid 34    
  value = value + (unsigned char) Temp;
  Write_Data_2_Display(0x0); 
  Write_Data_2_Display(0x0);
  Write_Command_2_Display(0x24); 
  Write_Data_2_Display(value); //borde det inte va C0 sen data write??? sid 28 i display data kan inneb�ra att vi inte clearar sk�rmen mellan varje print.
  Write_Command_2_Display(0xC0); 

}

void ReadLight(void){
  //Setup pins  
  
  
  unsigned int Light = /*pin out*/;
    
  unsigned char value = 0x10;           
  value = value + (unsigned char) Light; //look at the displayboard on blackboard on the diagram(reminder:
  Write_Data_2_Display(0x0); 
  Write_Data_2_Display(0x0);
  Write_Command_2_Display(0x24); 
  Write_Data_2_Display(value);
  Write_Command_2_Display(0xC0); 

}

//--------------------------------------------------------------------------Main loop


void main(void){
  
  SystemInit();
  configClock();
  SysTick_Config(84000);
  Init_Display();
  ClearDisp();
  
  /*(*PIOD_DIFSR) = (1 << 1); //
  (*PIOD_AIMER) = (1 << 1); //
  (*AT91C_PIOD_IFER) = (1 << 1);
  (*PIOD_SCDR) = (1 << 1); //bounce??
  (*AT91C_PIOD_ISR) = (1 << 1); 
  NVIC_ClearPendingIRQ(PIOD_IRQn);
  NVIC_SetPriority(PIOD_IRQn, 1);
  NVIC_EnableIRQ(PIOD_IRQn);
  (*AT91C_PIOD_PER) = (1 << 1); // PIO enable register
  (*AT91C_PIOD_IER) = (1 << 1); //Interrup enable register
  */
  
  while(1){
    
    if(interrupt == 1){
      interrupt = 0;
      ReadLight();
      ReadTemp();
  
    }
  }
}

main();